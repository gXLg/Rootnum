# rootnum
A python module for accurate square root operations
