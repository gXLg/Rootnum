from rootnum import Rootnum

num = Rootnum([(1, 1), (1, 5)], 2)
print(num)
a = num + (1, 2)
b = 1 / num
print(a)
print(b)
